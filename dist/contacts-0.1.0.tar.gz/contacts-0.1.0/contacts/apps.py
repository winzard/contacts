from django.apps.config import AppConfig


class ContactsApp(AppConfig):
    name = "contacts"